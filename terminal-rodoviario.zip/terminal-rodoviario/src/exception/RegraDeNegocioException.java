package exception;

public class RegraDeNegocioException extends Exception{

    public RegraDeNegocioException(String message) {
        super(message);
    }
}
