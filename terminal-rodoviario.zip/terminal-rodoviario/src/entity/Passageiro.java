package entity;

import java.time.LocalDate;

public class Passageiro implements Pessoa{

    public String nome;
    public String endereco;
    public LocalDate dataNascimento;
    public boolean temReserva;
    public String documento;

    public Passageiro(String nome, String endereco, LocalDate dataNascimento, String documento) {
        this.nome = nome;
        this.endereco = endereco;
        this.dataNascimento = dataNascimento;
        this.temReserva = false;
        this.documento=documento;
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public boolean isTemReserva() {
        return temReserva;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public LocalDate getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(LocalDate dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public void setTemReserva(boolean temReserva) {
        this.temReserva = temReserva;
    }

    public Boolean possuiReserva(){
        return temReserva;
    }

    @Override
    public String documentoPadrao() {
        return documento;
    }

    @Override
    public String toString() {
        return "Passageiro [ " +
                "Nome: " + nome + " | " +
                "Endereco: " + endereco + " | " +
                "Data Nascimento: " + dataNascimento +
                " ]";
    }


}
