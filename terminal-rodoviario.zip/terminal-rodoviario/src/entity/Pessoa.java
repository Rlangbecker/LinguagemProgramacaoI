package entity;

public interface Pessoa {
    public String documentoPadrao();
}
