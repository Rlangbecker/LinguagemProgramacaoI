package service;

import entity.Passageiro;
import exception.RegraDeNegocioException;
import service.enums.TipoPassagem;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class Executiva extends Bilhete{

    public Executiva(long id, int numero, String assento,Passageiro passageiro) {
        super(id, numero, assento,passageiro);
    }

    @Override
    public double valor() {
        return 125;
    }

    @Override
    public void reservar(TipoPassagem tipoPassagem, Bilhete bilhete, Passageiro passageiro) {
        super.reservar(tipoPassagem,bilhete,passageiro);
    }

    @Override
    public int maximoBagagens() {
        return 0;
    }

    @Override
    public Passageiro cadastrarPassageiro() {
        Scanner s = new Scanner(System.in);
        DateTimeFormatter formatador = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        while (true) {
            try {
                System.out.println("Insira seu nome:");
                String nome = s.nextLine();
                System.out.println("Insira seu endereco:");
                String endereco = s.nextLine();
                System.out.println("Insira sua data de nascimento: \n EXEMPLO(02/04/2004)");
                String dataNasc = s.nextLine();
                System.out.println("Insira seu documento: ");
                String documento = s.nextLine();
                LocalDate dataNascimento = LocalDate.parse(dataNasc, formatador);
                long diferencaIdade = ChronoUnit.YEARS.between(dataNascimento, LocalDate.now());
                if (diferencaIdade < 18) {
                    throw new RegraDeNegocioException("");
                }
                Passageiro passageiro = new Passageiro(nome, endereco, dataNascimento, documento);
                return passageiro;
            } catch (DateTimeException ex) {
                System.out.println("Erro na composição de data de nascimento");
            } catch (RegraDeNegocioException e) {
                System.out.println("Lamento, precisa ter mais de 18 anos para reservar um bilhete");
            }
        }
    }
}
