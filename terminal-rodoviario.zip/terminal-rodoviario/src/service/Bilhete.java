package service;

import entity.Passageiro;
import entity.Reserva;
import exception.RegraDeNegocioException;
import service.enums.TipoPassagem;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public abstract class Bilhete {
    public long id;
    public int numero;
    public String assento;

    public Passageiro passageiro;

    public Double valor;

    public List<Reserva> reservas;

    public Passageiro getPassageiro() {
        return passageiro;
    }

    public void setPassageiro(Passageiro passageiro) {
        this.passageiro = passageiro;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public Bilhete(long id, int numero, String assento, Passageiro passageiro) {
        this.id = id;
        this.numero = numero;
        this.assento = assento;
        this.passageiro = passageiro;
    }

    public Bilhete() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getAssento() {
        return assento;
    }

    public void setAssento(String assento) {
        this.assento = assento;
    }


    public void reservar(TipoPassagem tipoPassagem, Bilhete bilhete, Passageiro passageiro) {
        if (passageiro == null) {
            System.out.println("Lamento, faltaram informações de passageiro.");
        } else {
            Reserva reserva = new Reserva();
            reserva.setTipoPassagem(tipoPassagem);
            reserva.setBilhete(bilhete);
            reserva.setPassageiro(passageiro);
            if(TipoPassagem.ECONOMICA == tipoPassagem){
                reserva.setValor(TipoPassagem.ECONOMICA.ordinal());
            } else if (TipoPassagem.EXECUTIVA == tipoPassagem) {
                reserva.setValor(TipoPassagem.EXECUTIVA.ordinal());
            } else {
                reserva.setValor(TipoPassagem.PRIMEIRA_CLASSE.ordinal());
            }
            reservas.add(reserva);
        }

    }

    public void comprar() {

    }

    public void cancelarReserva() {

    }

    public abstract double valor();

    public abstract int maximoBagagens();

    public static Bilhete verificarIdBilhete(List<Bilhete> bilhetes, Bilhete bilhete) {
        Random random = new Random();
        for (Bilhete bilheteTemporario : bilhetes) {
            while (bilheteTemporario.id == bilhete.id || bilheteTemporario.getNumero() == bilhete.getNumero() || bilheteTemporario.getAssento().equals(bilhete.getAssento())) {
                if (bilheteTemporario.id == bilhete.id) {
                    bilhete.setId(random.nextInt());
                }
                if (bilheteTemporario.getNumero() == bilhete.getNumero()) {
                    bilhete.setId(random.nextInt(10000));
                }
                if (bilheteTemporario.assento.equals(bilhete.getAssento())) {
                    bilhete.setAssento(random.ints(1, 44).toString());
                }
            }
        }
        return bilhete;
    }

    public abstract Passageiro cadastrarPassageiro() throws RegraDeNegocioException;

    @Override
    public String toString() {
        return "Bilhete ->" +
                " ID: " + id +
                ", N°:" + numero +
                ", ASSENTO: " + assento + " " + passageiro;
    }
}
