package service.enums;

public enum TipoPassagem {
    ECONOMICA(100),
    EXECUTIVA(125),
    PRIMEIRA_CLASSE(150);

    private final double valor;

    TipoPassagem(double valor) {
        this.valor = valor;
    }
}
