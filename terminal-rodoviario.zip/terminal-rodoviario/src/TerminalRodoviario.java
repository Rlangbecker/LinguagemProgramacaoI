import exception.RegraDeNegocioException;
import entity.Passageiro;
import service.Bilhete;
import service.Economica;
import service.Executiva;
import service.PrimeiraClasse;
import service.enums.TipoPassagem;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class TerminalRodoviario {
    public static void main(String[] args) throws RegraDeNegocioException {
        Scanner s = new Scanner(System.in);
        Random random = new Random();

        Bilhete bilheteManipulacao = new Bilhete() {
            @Override
            public double valor() {
                return 0;
            }

            @Override
            public int maximoBagagens() {
                return 0;
            }

            @Override
            public Passageiro cadastrarPassageiro() throws RegraDeNegocioException {
                return null;
            }
        };

        Passageiro passageiro = new Passageiro("Ricardo", "Avenida dos Cubanos", LocalDate.of(1994, 07, 03), "12345");
        Passageiro passageiro1 = new Passageiro("Carlos", "Rua Albion", LocalDate.of(2002, 01, 12), "871368721");
        Passageiro passageiro2 = new Passageiro("Eduardo", "Rua professor Cristiano Fischer", LocalDate.of(2006, 04, 18), "63156219");

        List<Bilhete> bilhetes = new ArrayList<>();
        Economica bilhete1 = new Economica(1, 134986234, "42", passageiro);
        Economica bilhete2 = new Economica(2, 127532124, "13", passageiro1);
        bilhetes.add(bilhete1);
        bilhetes.add(bilhete2);

        while (true) {
            System.out.println("    1 - Reservar Bilhete    ");
            System.out.println("    2 - Verificar lista de reservas de Bilhete    ");
            System.out.println("    3 - Verificar disponibilidade por Bilhete");
            int opcao = s.nextInt();
            s.nextLine();

            switch (opcao) {
                case 1 -> {
                    System.out.println(" [1] ECONOMICA");
                    System.out.println(" [2] Executiva");
                    System.out.println(" [3] PRIMEIRA CLASSE");

                    int opcaoBilhete = s.nextInt();

                    switch (opcaoBilhete) {
                        case 1: {
                            int id = random.nextInt(7, 100);
                            int numero = random.nextInt(100000);
                            String assento = random.ints(1, 44).toString();
                            Passageiro passageiroBilhete = bilheteManipulacao.cadastrarPassageiro();

                            Economica bilheteEconomico = new Economica(id, numero, assento, passageiroBilhete);

                            Bilhete.verificarIdBilhete(bilhetes, bilheteEconomico);

                            System.out.println("Reserva efetuada! \n" +
                                    bilheteEconomico);
                            bilhetes.add(bilheteEconomico);
                            break;
                        }
                        case 2: {
                            int id = random.nextInt(7, 100);
                            int numero = random.nextInt(100000);
                            String assento = random.ints(1, 44).toString();

                            Passageiro passageiro3 = cadastrarPassageiro();

                            Executiva bilheteExecutivo = new Executiva(id, numero, assento, passageiro3);

                            Bilhete.verificarIdBilhete(bilhetes, bilheteExecutivo);

                            System.out.println("Reserva efetuada! \n" +
                                    bilheteExecutivo);
                            bilhetes.add(bilheteExecutivo);
                            break;
                        }
                        case 3: {
                            int id = random.nextInt(7, 100);
                            int numero = random.nextInt(100000);
                            String assento = random.ints(1, 44).toString();

                            Passageiro passageiro3 = cadastrarPassageiro();
                            PrimeiraClasse bilhetePrimeiraClasse = new PrimeiraClasse(id, numero, assento, passageiro3);

                            Bilhete.verificarIdBilhete(bilhetes, bilhetePrimeiraClasse);

                            System.out.println("Reserva efetuada! \n" +
                                    bilhetePrimeiraClasse);
                            bilhetes.add(bilhetePrimeiraClasse);
                            break;
                        }

                    }

                }

                case 2 -> {
                    verificarListaBilhetesEPassageiros(bilhetes);
                }

                case 3 -> {
                    System.out.println("Insira o ID do bilhete: ");
                    int id = s.nextInt();
                    s.nextLine();
                    verificarDisponibilidadeBilhete(bilhetes, id);
                    break;

                }
            }

        }

    }

    public static Passageiro cadastrarPassageiro() throws RegraDeNegocioException {
        Scanner s = new Scanner(System.in);
        DateTimeFormatter formatador = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        while (true) {
            try {
                System.out.println("Insira seu nome:");
                String nome = s.nextLine();
                System.out.println("Insira seu endereco:");
                String endereco = s.nextLine();
                System.out.println("Insira sua data de nascimento: \n EXEMPLO(02/04/2004)");
                String dataNasc = s.nextLine();
                System.out.println("Insira seu documento: ");
                String documento = s.nextLine();
                LocalDate dataNascimento = LocalDate.parse(dataNasc, formatador);
                long diferencaIdade = ChronoUnit.YEARS.between(dataNascimento, LocalDate.now());
                if (diferencaIdade < 18) {
                    throw new RegraDeNegocioException("");
                }
                Passageiro passageiro = new Passageiro(nome, endereco, dataNascimento, documento);
                return passageiro;
            } catch (DateTimeException ex) {
                System.out.println("Erro na composição de data de nascimento");
            } catch (RegraDeNegocioException e) {
                System.out.println("Lamento, precisa ter mais de 18 anos para reservar um bilhete");
            }
        }
    }

    public static void verificarDisponibilidadeBilhete(List<Bilhete> bilhetes, Integer id) {
        if (bilhetes.stream().anyMatch(bilhete -> bilhete.id == id)) {
            System.out.println("Bilhete indisponivel");
        } else {
            System.out.println("Bilhete disponível");
        }
    }

    public static void verificarListaBilhetesEPassageiros(List<Bilhete> bilhetes) {
        bilhetes.stream()
                .forEach(bilhete -> {
                    System.out.println(bilhete);
                });
    }
}